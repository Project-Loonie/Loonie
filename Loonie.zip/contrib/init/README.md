Sample configuration files for:

SystemD: loonied.service
Upstart: loonied.conf
OpenRC:  loonied.openrc
         loonied.openrcconf
CentOS:  loonied.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
